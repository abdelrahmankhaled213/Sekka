import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sekka/Core/Cubit/pick_image_cubit.dart';
import 'package:sekka/Core/Navigation/custom_route_builder.dart';
import 'package:sekka/Core/Navigation/main_bottom_nav_view.dart';
import 'package:sekka/Features/Auth/Logic/set_up_profile_cubit.dart';
import 'package:sekka/Features/Auth/Ui/SetUpProfile/View/setup_profile_view.dart';
import 'package:sekka/Features/OnBoarding/Ui/Views/OnBoardingView.dart';
import '../../Features/Auth/Ui/auth_wrapper_view.dart';
import '../../Features/Splash/View/splash_screen_view.dart';
import '../Constants/app_route.dart';
import '../DI/service_locator.dart';

  Route<dynamic> onGenerateRoute(RouteSettings settings) {

    switch (settings.name) {

      case AppRoute.splash:
        return CustomPageRoute(page: SplashScreenView());

      case AppRoute.onBoarding:
        return CustomPageRoute(page: OnBoardingView());

      case AppRoute.authWrapper:
        return CustomPageRoute(page: AuthWrapper());

      case AppRoute.setUpProfile:
        return CustomPageRoute(
            page: MultiBlocProvider(providers: [

              BlocProvider(create: (context) {
                return getIt<SetUpProfileCubit>();
              }
              ),

              BlocProvider(create: (context) {
                return getIt<PickImageCubit>();
              }
              ),



            ], child: SetupProfileView())
        );

      case AppRoute.bottomNavigation:
        return CustomPageRoute(page:MainScreen() );

case AppRoute.itemDetailAndChatScreen:


      default:
        return MaterialPageRoute(
            builder: (_) => SplashScreenView()
        );
    }
  }
