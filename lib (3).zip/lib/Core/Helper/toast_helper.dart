
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:sekka/Core/Constants/app_color.dart';

class FlutterToastHelper{
  static Future<void>showToast({required String
   text,Color?color}) async {

   await  Fluttertoast.showToast(
        msg: text,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.CENTER,
        timeInSecForIosWeb: 1,
        backgroundColor: color??AppColor.main,
        textColor: Colors.white,
        fontSize: 14.sp
    );

}
}