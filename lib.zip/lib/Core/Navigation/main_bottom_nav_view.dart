import 'dart:ui';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:sekka/Core/Cubit/pick_image_cubit.dart';
import 'package:sekka/Core/DI/service_locator.dart';
import 'package:sekka/Features/NearestStation/Logic/nearest_station_cubit.dart';
import 'package:sekka/Features/NearestStation/Ui/Widget/View/nearest_station_view.dart';
import 'package:sekka/Features/Profile/Logic/profile_cubit.dart';
import 'package:sekka/Features/Profile/Logic/trip_history_cubit.dart';
import 'package:sekka/Features/Profile/UI/profile_screen.dart';
import 'package:sekka/Features/WhereToGo/Logic/where_to_go_cubit.dart';
import 'package:sekka/Features/WhereToGo/Ui/Widgets/Screens/where_to_go.dart';
import 'package:sekka/core/theme/app_colors.dart';
import 'package:sekka/core/theme/app_radius.dart';
import 'package:sekka/core/theme/app_spacing.dart';
import 'package:sekka/core/theme/app_text_styles.dart';
import 'package:sekka/Features/ChatBot/Ui/View/chat_bot_view.dart';
import 'package:sekka/Features/LostAndFound/Logic/lost_found.dart';
import 'package:sekka/Features/LostAndFound/View/home_feed_screen_view.dart';
import 'package:sekka/Features/Routes/Logic/routes_cubit.dart';
import 'package:sekka/Features/Routes/Ui/Widget/View/routes_screen_view.dart';

class _K {
  const _K._();
  static const Duration pill   = Duration(milliseconds: 320);
  static const Duration icon   = Duration(milliseconds: 260);
  static const Duration tap    = Duration(milliseconds: 180);
  static const Duration slide  = Duration(milliseconds: 350);
  static const BorderRadius nav = AppRadius.allXXL;
  static const BorderRadius itm = AppRadius.allLG;
  static const double blur     = 16;
  static const int centerIndex = 2;
}

class _NavItem {
  const _NavItem({
    required this.label,
    required this.icon,
    required this.activeIcon,
    this.isCenter = false,
  });
  final String   label;
  final IconData icon;
  final IconData activeIcon;
  final bool     isCenter;
}

class MainBottomNavView extends StatefulWidget {
  const MainBottomNavView({super.key});

  @override
  State<MainBottomNavView> createState() => _MainBottomNavViewState();
}

class _MainBottomNavViewState extends State<MainBottomNavView> {
  @override
  void initState() {
    super.initState();
    FirebaseMessaging.instance.subscribeToTopic("comments");
    FirebaseMessaging.instance.subscribeToTopic("posts");  
  }

  int  _currentIndex = 0;
  bool _isVisible    = true;

  static const List<_NavItem> _items = [
    _NavItem(label: 'Home',         icon: Icons.home_outlined,    activeIcon: Icons.home_rounded),
    _NavItem(label: 'Routes',       icon: Icons.route_outlined,   activeIcon: Icons.route_rounded),
    _NavItem(label: 'Map',          icon: Icons.map_outlined,     activeIcon: Icons.map_rounded, isCenter: true),
    _NavItem(label: 'Lost & Found', icon: Icons.restore_outlined, activeIcon: Icons.restore_rounded),
    _NavItem(label: 'Profile',      icon: Icons.person_outline,   activeIcon: Icons.person_rounded),
  ];

  late final List<Widget> _tabs = [
    BlocProvider(
      create: (_) => getIt<WhereToGoCubit>(),
      child: const WhereToGoScreen(),
    ),
    BlocProvider(
      create: (_) => getIt<RoutesCubit>()..fetchTransports(),
      child: const RoutesScreenView(),
    ),
    BlocProvider(
      create: (_) => getIt<NearestStationCubit>(),
      child: const NearestStationView(),
    ),
    BlocProvider(
      create: (_) => getIt<LostAndFoundCubit>()..getPosts(),
      child: const HomeFeedScreen(),
    ),
    MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => getIt<ProfileCubit>()..getProfile()),
        BlocProvider(create: (_) => getIt<PickImageCubit>()),
        BlocProvider(create: (_) => getIt<TripHistoryCubit>()),
      ],
      child: const ProfileScreen(),
    ),
  ];

  void _onTabSelected(int index) {
    if (_currentIndex == index) return;
    setState(() => _currentIndex = index);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      extendBody: true,
      // استخدمنا Stack هنا عشان الـ ChatBot يتحرك بحرية فوق الـ Tabs والـ Nav Bar
      body: Stack(
        children: [
          NotificationListener<UserScrollNotification>(
            onNotification: (n) {
              if (n.direction == ScrollDirection.reverse && _isVisible) {
                setState(() => _isVisible = false);
              } else if (n.direction == ScrollDirection.forward && !_isVisible) {
                setState(() => _isVisible = true);
              }
              return true;
            },
            child: IndexedStack(index: _currentIndex, children: _tabs),
          ),
          
          // استدعاء زرار الشات الـ Draggable هنا وتمرير حالة الـ Navigation Bar
          _ChatBotFab(navVisible: _isVisible),
        ],
      ),
      bottomNavigationBar: AnimatedSlide(
        duration: _K.slide,
        curve: Curves.easeInOut,
        offset: _isVisible ? Offset.zero : const Offset(0, 1.5),
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 300),
          opacity: _isVisible ? 1.0 : 0.0,
          child: Padding(
            padding: EdgeInsets.fromLTRB(AppSpacing.lg.w, 0, AppSpacing.lg.w, AppSpacing.xl.h),
            child: _NavBar(
              currentIndex: _currentIndex,
              items: _items,
              onTap: _onTabSelected,
            ),
          ),
        ),
      ),
    );
  }
}

class _NavBar extends StatelessWidget {
  const _NavBar({
    required this.currentIndex,
    required this.items,
    required this.onTap,
  });

  final int currentIndex;
  final List<_NavItem> items;
  final ValueChanged<int> onTap;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: _K.nav,
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: _K.blur, sigmaY: _K.blur),
        child: Container(
          padding: EdgeInsets.symmetric(horizontal: AppSpacing.sm.w, vertical: AppSpacing.sm.h),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.72),
            borderRadius: _K.nav,
            border: Border.all(color: Colors.white.withOpacity(0.5)),
            boxShadow: const [
              BoxShadow(
                color: Color(0x1A000000),
                blurRadius: 24,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: Row(
            children: List.generate(items.length, (i) {
              final item = items[i];
              if (item.isCenter) {
                return _CenterItem(
                  isSelected: currentIndex == i,
                  onTap: () => onTap(i),
                );
              }
              return Expanded(
                child: _NavItemWidget(
                  item: item,
                  isSelected: currentIndex == i,
                  showBadge: i == 2,
                  onTap: () => onTap(i),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

class _CenterItem extends StatefulWidget {
  const _CenterItem({required this.isSelected, required this.onTap});
  final bool isSelected;
  final VoidCallback onTap;

  @override
  State<_CenterItem> createState() => _CenterItemState();
}

class _CenterItemState extends State<_CenterItem> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: _K.tap,
    lowerBound: 0,
    upperBound: 0.06,
  );

  Future<void> _onTap() async {
    await _ctrl.forward();
    await _ctrl.reverse();
    widget.onTap();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 72.w,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, child) => Transform.scale(scale: 1 - _ctrl.value, child: child),
        child: GestureDetector(
          onTap: _onTap,
          behavior: HitTestBehavior.opaque,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              AnimatedContainer(
                duration: _K.icon,
                width: 52.w,
                height: 52.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: LinearGradient(
                    colors: widget.isSelected
                        ? [AppColors.primary, AppColors.secondary]
                        : [
                            AppColors.primary.withOpacity(0.8),
                            AppColors.secondary.withOpacity(0.8),
                          ],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(widget.isSelected ? 0.4 : 0.2),
                      blurRadius: widget.isSelected ? 14 : 8,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(
                  widget.isSelected ? Icons.map_rounded : Icons.map_outlined,
                  color: Colors.white,
                  size: 24.sp,
                ),
              ),
              SizedBox(height: AppSpacing.xs.h),
              AnimatedDefaultTextStyle(
                duration: _K.icon,
                style: AppTextStyles.labelSmall(context).copyWith(
                  fontWeight: FontWeight.w700,
                  color: widget.isSelected ? AppColors.primary : AppColors.grey,
                ),
                child: const Text(
                  'Map',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  textAlign: TextAlign.center,
                  softWrap: false,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _NavItemWidget extends StatefulWidget {
  const _NavItemWidget({
    required this.item,
    required this.isSelected,
    required this.onTap,
    this.showBadge = false,
  });

  final _NavItem     item;
  final bool         isSelected;
  final VoidCallback onTap;
  final bool         showBadge;

  @override
  State<_NavItemWidget> createState() => _NavItemWidgetState();
}

class _NavItemWidgetState extends State<_NavItemWidget> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: _K.tap,
    lowerBound: 0,
    upperBound: 0.07,
  );

  Future<void> _onTap() async {
    await _ctrl.forward();
    await _ctrl.reverse();
    widget.onTap();
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ctrl,
      builder: (_, child) => Transform.scale(scale: 1 - _ctrl.value, child: child),
      child: GestureDetector(
        onTap: _onTap,
        behavior: HitTestBehavior.opaque,
        child: AnimatedContainer(
          duration: _K.pill,
          curve: Curves.easeOutCubic,
          padding: EdgeInsets.symmetric(horizontal: AppSpacing.sm.w, vertical: AppSpacing.sm.h),
          decoration: BoxDecoration(
            color: widget.isSelected ? AppColors.primary.withOpacity(0.1) : Colors.transparent,
            borderRadius: _K.itm,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                clipBehavior: Clip.none,
                children: [
                  AnimatedSwitcher(
                    duration: _K.icon,
                    transitionBuilder: (child, anim) => ScaleTransition(
                      scale: anim,
                      child: FadeTransition(opacity: anim, child: child),
                    ),
                    child: Icon(
                      widget.isSelected ? widget.item.activeIcon : widget.item.icon,
                      key: ValueKey(widget.isSelected),
                      color: widget.isSelected ? AppColors.primary : AppColors.grey,
                      size: 22.sp,
                    ),
                  ),
                  if (widget.showBadge)
                    Positioned(
                      top: -3,
                      right: -6,
                      child: Container(
                        width: 14.w,
                        height: 14.w,
                        decoration: BoxDecoration(
                          color: AppColors.primary,
                          shape: BoxShape.circle,
                          border: Border.all(color: Colors.white, width: 1.5),
                        ),
                        child: Center(
                          child: Text(
                            '3',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 8.sp,
                              fontWeight: FontWeight.w700,
                              fontFamily: 'Roboto',
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
              SizedBox(height: AppSpacing.xs.h),
              AnimatedDefaultTextStyle(
                duration: _K.icon,
                style: AppTextStyles.labelSmall(context).copyWith(
                  fontWeight: widget.isSelected ? FontWeight.w700 : FontWeight.w500,
                  color: widget.isSelected ? AppColors.primary : AppColors.grey,
                ),
                child: Text(
                  widget.item.label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ── التعديل الأساسي هنا للـ ChatBot ليصبح قابل للسحب (Draggable) ──
class _ChatBotFab extends StatefulWidget {
  const _ChatBotFab({required this.navVisible});
  final bool navVisible;

  @override
  State<_ChatBotFab> createState() => _ChatBotFabState();
}

class _ChatBotFabState extends State<_ChatBotFab> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 180),
    lowerBound: 0,
    upperBound: 0.07,
  );

  // هنا بنخزن الـ Y Position المبدئي للزرار
  double _yPosition = 500.0;
  bool _isFirstLayout = true;

  Future<void> _onTap() async {
    await _ctrl.forward();
    await _ctrl.reverse();
    if (!mounted) return;
    _openChatBot();
  }

  void _openChatBot() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (_) => DraggableScrollableSheet(
        initialChildSize: 0.92,
        minChildSize: 0.5,
        maxChildSize: 0.95,
        builder: (_, __) => Container(
          decoration: BoxDecoration(
            color: AppColors.surface,
            borderRadius: BorderRadius.vertical(top: Radius.circular(AppSpacing.xxl)),
          ),
          child: Column(
            children: [
              Container(
                width: 36.w,
                height: 4.h,
                margin: EdgeInsets.symmetric(vertical: AppSpacing.md.h),
                decoration: BoxDecoration(
                  color: const Color(0xFFE5E7EB),
                  borderRadius: AppRadius.allXS,
                ),
              ),
              const Expanded(child: ChatBotView()),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final mediaQuery = MediaQuery.of(context);
    final screenHeight = mediaQuery.size.height;
    final bottomPadding = mediaQuery.padding.bottom;
    final topPadding = mediaQuery.padding.top;

    // لتحديد مكانه المبدئي فوق الـ Bottom Nav Bar أول ما الشاشة تفتح
    if (_isFirstLayout && screenHeight > 0) {
      _yPosition = screenHeight - bottomPadding - 160.h;
      _isFirstLayout = false;
    }

    return Positioned(
      right: 16.w, // مسافة ثابتة من اليمين
      top: _yPosition,
      child: AnimatedSlide(
        duration: _K.slide,
        curve: Curves.easeInOut,
        // بيختفي وينزل لو الـ Nav Bar اختفت أثناء الـ Scroll
        offset: widget.navVisible ? Offset.zero : const Offset(0, 2),
        child: AnimatedOpacity(
          duration: const Duration(milliseconds: 300),
          opacity: widget.navVisible ? 1.0 : 0.0,
          child: AnimatedBuilder(
            animation: _ctrl,
            builder: (_, child) => Transform.scale(scale: 1 - _ctrl.value, child: child),
            child: GestureDetector(
              onTap: _onTap,
              // تفعيل ميزة السحب فوق وتحت
              onVerticalDragUpdate: (details) {
                setState(() {
                  _yPosition += details.delta.dy;

                  // حماية الزرار عشان ما يخرجش بره الشاشة (بين الـ Status Bar والـ Nav Bar)
                  double minTop = topPadding + 20.h;
                  double maxBottom = screenHeight - bottomPadding - 140.h;

                  if (_yPosition < minTop) _yPosition = minTop;
                  if (_yPosition > maxBottom) _yPosition = maxBottom;
                });
              },
              child: Container(
                width: 48.w,
                height: 48.w,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: const LinearGradient(
                    colors: [AppColors.primary, AppColors.secondary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                  boxShadow: [
                    BoxShadow(
                      color: AppColors.primary.withOpacity(0.35),
                      blurRadius: 12,
                      offset: const Offset(0, 4),
                    ),
                  ],
                ),
                child: Icon(
                  Icons.smart_toy_rounded,
                  color: Colors.white,
                  size: 22.sp,
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}